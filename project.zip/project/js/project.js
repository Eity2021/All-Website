$(document).ready(function(){
    $('#bttn').click(function(){
        $('#slide').slideToggle('slow');
    })
})

$(document).ready(function(){
    $('#bttn2').click(function(){
        $('#slider').slideToggle('slow');
    })
})
